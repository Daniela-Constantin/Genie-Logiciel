package projet;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;


public class LocationTest {
    
    public LocationTest() {
    }
    
    int nb_pl_ext, nb_pl_int;
    float s_ext, s_int;
    String nom;
    Location instance1;
    
    @Before
    public void setUp() throws Exception {
        //initialisation des variables 
        nb_pl_ext = 50;
        nb_pl_int = 150;
        s_ext = 64;
        s_int = 81;
        nom = "ComicsClub";
        instance1 = new Location(nom, nb_pl_int, nb_pl_ext, s_int, s_ext);
    }

    @Test
    public void testNb_total_places() {
        System.out.println("Nb_total_places");
        int expResult = 200;
        instance1.setNb_total_places(200);
        int result = instance1.getNb_total_places();
        assertEquals(expResult, result);
        assertEquals(result, nb_pl_ext + nb_pl_int);
    }

    @Test
    public void testNb_places_interieur() {
        System.out.println("Nb_places_interieur");
        int expResult = 150;
        int result = instance1.getNb_places_interieur();
        assertEquals(expResult, result);
    }

    @Test
    public void testNb_places_exterieur() {
        System.out.println("Nb_places_exterieur");
        int expResult = 50;
        int result = instance1.getNb_places_exterieur();
        assertEquals(expResult, result);
    }

    @Test
    public void testDensiteInterieur() {
        System.out.println("densiteInterieur");
        float expResult = 1.85F;
        float result = instance1.densiteInterieur();
        assertEquals(expResult, result, 1.85);
    }

    @Test
    public void testDensiteExterieur() {
        System.out.println("densiteExterieur");
        float expResult = 0.78F;
        float result = instance1.densiteExterieur();
        assertEquals(expResult, result, 0.78);
    }
    
    
    //TEST METHODES COMPLEXES REALISE PAR DANIELA CONSTANTIN
    @Test
    public void testVerifieConformiteInterieur(){
        System.out.println("verifieConformiteInterieur");
        float expDens = 1.85F;
        float dens = instance1.densiteInterieur();
        assertEquals(expDens, dens, 1.85);
        
        if(dens > 0.25){
            int places_int = instance1.getNb_places_interieur();
            int expNbPlacesARennoncer = 20;
            int expNbPlacesApresSustraction = 130;
            int NbPlacesARennoncer = instance1.verifieConformiteInterieur();
            assertEquals(expNbPlacesARennoncer, NbPlacesARennoncer);
            assertEquals(places_int - NbPlacesARennoncer, expNbPlacesApresSustraction);
        }
    }
    
    @Test
    public void testVerifieConformiteExterieur(){
        System.out.println("verifieConformiteExterieur");
        float expDens = 0.78F;
        float dens = instance1.densiteExterieur();
        assertEquals(expDens, dens, 0.78);
        
        if(dens > 0.5){
            int places_ext = instance1.getNb_places_exterieur();
            int expNbPlacesARennoncer = 32;
            int expNbPlacesApresSustraction = 18;
            int NbPlacesARennoncer = instance1.verifieConformiteExterieur();
            assertEquals(expNbPlacesARennoncer, NbPlacesARennoncer);
            assertEquals(places_ext - NbPlacesARennoncer, expNbPlacesApresSustraction);
        }
    }
    //FIN TEST METHODES COMPLEXES REALISE PAR DANIELA CONSTANTIN
    
}
