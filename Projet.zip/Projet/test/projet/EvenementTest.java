package projet;

import java.util.ArrayList;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;


public class EvenementTest {
    
    public EvenementTest() {
    }
    
    int code;
    String nom;
    Evenement instance;
    
    @Before
    public void setUp() throws Exception {
        //initialisation des variables 
        code = 1;
        nom = "Stand-up show";
        instance = new Evenement(code, nom);
    }
    

    @Test
    public void testLocation() {
        System.out.println("Location");
        Location location = new Location("ComicsClub", 150, 50, 81, 64);
        instance.setLocation(location);
        assertFalse(location.equals(null));
        assertEquals(instance.getLocation(), location);
    }

    @Test
    public void testPrixMoyen() {
        System.out.println("PrixMoyen");
        float prixMoyen = 35;
        instance.setPrixMoyen(prixMoyen);
        assertTrue(instance.getPrixMoyen() == prixMoyen);
    }

    @Test
    public void testDescription() {
        System.out.println("Description");
        String description = "Soiree comique";
        instance.setDescription(description);
        assertEquals(instance.getDescription(), description);
    }

    @Test
    public void testLienVersBillet() {
        System.out.println("LienVersBillet");
        String lienVersBillet = "https://comicsclub.ro/";
        instance.setLienVersBillet(lienVersBillet);
        assertEquals(instance.getLienVersBillet(), lienVersBillet);
    }
    
}
