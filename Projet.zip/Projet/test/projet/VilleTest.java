package projet;

import java.util.ArrayList;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class VilleTest {
    
    public VilleTest() {
    }
    
    int ncas, nres;
    String nom;
    Code_Etat cetat;
    ArrayList<Evenement> liste_even = new ArrayList<Evenement>();
    Ville instance;
    
    @Before
    public void setUp() throws Exception {
        //initialisation des variables 
        ncas = 114272;
        nres = 1883425;
        nom = "Bucarest";
        instance = new Ville(nom, ncas, nres);
    }
    
    @Test
    public void testNom() {
        System.out.println("getNom");
        String result = instance.getNom();
        assertTrue(result.equalsIgnoreCase(nom));
    }
    

    @Test
    public void testNoCas() {
        System.out.println("NoCas");
        int result = instance.getNoCas();
        assertTrue(result == ncas);
        assertTrue(result <= nres);
    }
    
    @Test
    public void testNoResidents() {
        System.out.println("NoResidents");
        int result = instance.getNoResidents();
        assertTrue(result == nres);
    }


    //TEST METHODES COMPLEXES REALISE PAR ROBERT DOVLETE
    @Test
    public void testPourcentageInfections() {
        System.out.println("pourcentageInfections");
        float expResult = 6.06724451F;
        float result = instance.pourcentageInfections();
        int numitor = instance.getNoResidents();
        int numarator = instance.getNoCas();
        
        //ON VERIFIE SI LA FRACTION N'EST PAS SUPRAUNITAIRE
        assertTrue(numarator <= numitor);
        
        //ON VERIFIE SI LE POURCENT NE PASSE PAS 100
        assertTrue(result <= 100);
        
        //ON VERIFIE SI LE RESULTAT OBTENU EST CELUI QU'ON ATTENDAIT
        assertTrue(result == expResult);
    }   

    @Test
    public void testManipulationListeEvenements() {
        System.out.println("Manipulations Liste Evenements");
        Evenement e = new Evenement(1, "Stand-up Show");
        instance.addEvenement(e);
        liste_even = instance.getListeEvenements();
        assertFalse(liste_even.isEmpty());
        assertEquals(liste_even.size(), 1);
        assertTrue(liste_even.contains(e));
        
        instance.deleteEvenement(e);
        liste_even = instance.getListeEvenements();
        assertTrue(liste_even.isEmpty());
        assertFalse(liste_even.contains(e));
    }
    //FIN TEST METHODES COMPLEXES REALISE PAR ROBERT DOVLETE
    
    @Test
    public void testEtat() {
        System.out.println("Etat");
        instance.setEtat();
        cetat = instance.getEtat();
        assertTrue(cetat.equals(Code_Etat.ROUGE));
    }
    
    @Test
    public void testVerifiePermissionInterieur(){
        System.out.println("Verifie Permission Interieur");
        boolean interieur = instance.verifiePermissionInterieur();
        assertTrue(interieur==false);
    }
    
    @Test
    public void testVerifiePermissionExterieur(){
        System.out.println("Verifie Permission Exterieur");
        boolean exterieur = instance.verifiePermissionExterieur();
        assertTrue(exterieur==true);
    }
    
    
}
