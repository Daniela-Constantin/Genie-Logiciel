package projet;

import java.util.ArrayList;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ClientTest {
    
    public ClientTest() {
    }
    
    int id;
    String nom, prenom, tel, email, mdp;
    Client instance;
    private ArrayList<Evenement> lFavoris = new ArrayList<Evenement>();
    Evenement evenement2, evenement3;
    Location location2, location3;
    
    @Before
    public void setUp() throws Exception {
        //initialisation des variables 
        id = 1;
        nom = "Etudiant";
        prenom = "Fils";
        tel = "0732971305";
        email = "etud@fils.ro";
        mdp = "annee4";
        instance = new Client(id, nom, prenom, tel, email, mdp);
        
        location2 = new Location("Teatrul National", 500, 150, 200, 200);
        location3 = new Location("Arena Nationala", 0, 2000, 0, 500);
        
        evenement2 = new Evenement(2, "Piece de theatre");
        evenement2.setLienVersBillet("https://www.tnb.ro/ro");
        evenement2.setLocation(location2);
        
        evenement3 = new Evenement(3, "Concert");
        evenement3.setLienVersBillet("https://www.eventim.ro/en/");
        evenement3.setLocation(location3);
        
    }

    //TEST METHODES COMPLEXES REALISE PAR JUSTIN STANCULESCU
    @Test
    public void testListeEvenementsFavoris() {
        System.out.println("Manipuler Evenements Favoris");
        instance.ajouterEvenementAuxFavoris(evenement2);
        instance.ajouterEvenementAuxFavoris(evenement3);
        lFavoris = instance.getListeFavoris();
        assertFalse(lFavoris.isEmpty());
        assertEquals(lFavoris.size(), 2);
        assertTrue(lFavoris.contains(evenement2));
        assertTrue(lFavoris.contains(evenement3));
        
        instance.supprimerEvenementDeFavoris(evenement2);
        lFavoris = instance.getListeFavoris();
        assertFalse(lFavoris.isEmpty());
        assertEquals(lFavoris.size(), 1);
        assertFalse(lFavoris.contains(evenement2));
        assertTrue(lFavoris.contains(evenement3));
    }
    

    @Test
    public void testAcheterBilletExterieur() {
        System.out.println("acheterBilletExterieur");
        
        assertTrue(evenement2.getLocation().getNb_places_exterieur() >= 1);
        
        String result = instance.acheterBilletExterieur(evenement2);
        int nr_tot_apres_achat = evenement2.getLocation().getNb_total_places();
        int nr_ext_apres_achat = evenement2.getLocation().getNb_places_exterieur();
        

        assertEquals(result, "https://www.tnb.ro/ro");
        
        assertEquals(nr_ext_apres_achat, location2.getNb_places_exterieur());
        assertEquals(nr_tot_apres_achat, location2.getNb_total_places());
    }

    @Test
    public void testAcheterBilletInterieur() {
        System.out.println("acheterBilletInterieur");

        String result = instance.acheterBilletInterieur(evenement3);
        assertEquals(result, "Aucun place disponible a l'interieur");
    }
    //FIN TEST METHODES COMPLEXES REALISE PAR JUSTIN STANCULESCU
}
