package projet;

public class Utilisateur {
    private int ID;
    private String nom;
    private String prenom;
    private String tel;
    private String email;
    private String mot_de_passe;

    public Utilisateur() {
    }

    public Utilisateur(int ID, String nom, String prenom, String tel, String email, String mot_de_passe) {
        this.ID = ID;
        this.nom = nom;
        this.prenom = prenom;
        this.tel = tel;
        this.email = email;
        this.mot_de_passe = mot_de_passe;
    }
}
