package projet;

public class Location {
    private String nom;
    private boolean interieur;
    private boolean exterieur;
    private int nb_places_interieur;
    private int nb_places_exterieur;
    private int nb_total_places;
    private float surface_interieur;
    private float surface_exterieur;

    public Location(String nom, int nb_places_interieur, int nb_places_exterieur, float surface_interieur, float surface_exterieur) {
        this.nom = nom;
        this.nb_places_interieur = nb_places_interieur;
        this.nb_places_exterieur = nb_places_exterieur;
        this.surface_interieur = surface_interieur;
        this.surface_exterieur = surface_exterieur;
    }
    
    public int getNb_total_places() {
        return nb_total_places;
    }

    public int getNb_places_interieur() {
        return nb_places_interieur;
    }

    public int getNb_places_exterieur() {
        return nb_places_exterieur;
    }

    public void setNb_total_places(int nb_total_places) {
        this.nb_total_places = nb_total_places;
    }

    public void setNb_places_interieur(int nb_places_interieur) {
        this.nb_places_interieur = nb_places_interieur;
    }

    public void setNb_places_exterieur(int nb_places_exterieur) {
        this.nb_places_exterieur = nb_places_exterieur;
    }
    
    public float densiteInterieur(){
        float nr_places = this.nb_places_interieur;
        float d = nr_places/surface_interieur;
        return d;
    }
    
    public float densiteExterieur(){
        float nr_places = this.nb_places_exterieur;
        float d = nr_places/surface_exterieur;
        return d;
    }
    
    //Daca densitatea este mai mare de 1loc/4m^2, atunci trebuie sa mai scadem din locuri, pentru a reduce densitatea
    //Se vor returna nr. de locuri care trebuie scazute din totalul celor disponibile, sau -1 daca nu se pot scadea suficieinte ca sa atingem denistatea dorita
    public int verifieConformiteInterieur(){
        float densite = this.densiteInterieur();
        //Daca densitatea e prea mare
        if(densite > 0.25){
            //Calculam nr preferabil de locuri ce ar trebui puse la vanzare
            int loc_pref = (int) (0.25 * surface_interieur);
            //verificam daca nr de locuri existent permite inlaturarea nr. respectiv de locuri (daca avem de unde scadea atatea)
            //Daca da, se realizeaza scaderea si se returneaza nr de locuri la care trebuie sa renuntam
            if(nb_places_interieur > loc_pref){
                this.setNb_places_interieur(nb_places_interieur - loc_pref);
                return loc_pref;
            }
            //Daca nu avem suficiente de unde scadea, se returneaza -1
            return -1;
        }
        return 0;
    }
    
    public int verifieConformiteExterieur(){
        float densite = this.densiteExterieur();
        if(densite > 0.5){
            int loc_pref = (int) (0.5 * surface_exterieur);
            if(nb_places_exterieur > loc_pref){
                this.setNb_places_exterieur(nb_places_exterieur - loc_pref);
                return loc_pref;
            }
            return -1;
        }
        return 0;
    }
}
