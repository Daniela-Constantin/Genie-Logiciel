package projet;

public class Representant_Etablissement extends Utilisateur{
    private String etablissement;

    public Representant_Etablissement() {
        
    }

    public Representant_Etablissement(String etablissement, int ID, String nom, String prenom, String tel, String email, String mot_de_passe) {
        super(ID, nom, prenom, tel, email, mot_de_passe);
        this.etablissement = etablissement;
    }

    public void setEtablissement(String etablissement) {
        this.etablissement = etablissement;
    }

    public String getEtablissement() {
        return etablissement;
    }
    
    
}
