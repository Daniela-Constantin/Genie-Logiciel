package projet;

public class Evenement {
    private int CODE;
    private String nom;
    private Ville ville;
    private Location location;
    private float prixMoyen;
    private String description;
    private String lienVersBillet;

    public Evenement(int CODE, String nom) {
        this.CODE = CODE;
        this.nom = nom;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public void setPrixMoyen(float prixMoyen) {
        this.prixMoyen = prixMoyen;
    }

    public float getPrixMoyen() {
        return prixMoyen;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public String getLienVersBillet() {
        return lienVersBillet;
    }

    public void setLienVersBillet(String lienVersBillet) {
        this.lienVersBillet = lienVersBillet;
    }

    public Location getLocation() {
        return location;
    }    
}
