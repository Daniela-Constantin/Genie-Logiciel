package projet;

import java.util.ArrayList;
import java.util.Scanner;

public class Projet {

    public static void main(String[] args) {
        int choice;
        ArrayList<Ville> listeVilles = new ArrayList<Ville>();
        
        Scanner in = new Scanner(System.in);
        // Display the menu
        System.out.println("1\t Ajouter ville");
        System.out.println("2\t Ajouter evenement");
        System.out.println("3\t S'identifier");
        System.out.println("Appuyez sur 0 pour quitter le menu");
        System.out.println();
        
         
        //Display the title of the chosen module
//        do{
//            //Get user's choice
//            System.out.println("Veuillez saisir votre choix:");
//            choice=in.nextInt();
//            switch (choice) {
//                case 1: System.out.println("Ajouter ville"); 
//                        Ville v = new Ville();
//                        float test = v.pourcentageInfections();
//                        System.out.println("Pourcentage infections: " + test);
//                        v.setEtat();
//                        //System.out.println(v.toString());
//                        listeVilles.add(v);
//                        for(int i=0; i<listeVilles.size(); i++)
//                            System.out.println(listeVilles.get(i).toString());
//                        break;
//                case 2: System.out.println("Ajouter evenement");
//                        Evenement e = new Evenement();
//                        break;
//                case 3: System.out.println("S'identifier"); 
//                        break;
//                default: System.out.println("Sortir");
//            }
//        }while(choice != 0);

    }
    
}
