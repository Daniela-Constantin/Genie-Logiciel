package projet;

public enum Code_Etat{
        JAUNE,
        ORANGE,
        ROUGE
};
