package projet;

import java.util.ArrayList;

public class Ville {
    private String nom;
    private int noCas;
    private int noResidents;
    private Code_Etat etat;
    private ArrayList<Evenement> listeEvenements = new ArrayList<Evenement>();

    public Ville(String nom, int noCas, int noResidents) {
        this.nom = nom;
        this.noCas = noCas;
        this.noResidents = noResidents;
    }

    public String getNom() {
        return nom;
    }

    public int getNoCas() {
        return noCas;
    }

    public int getNoResidents() {
        return noResidents;
    }
    
    public float pourcentageInfections(){
        float c = this.noCas;
        float r = this.noResidents;
        float noInf = c/r * 100;
        return noInf;
    }

    public void setEtat() {
        float noInf = pourcentageInfections();
        if(noInf < 0.5)
            this.etat = Code_Etat.JAUNE;
        if(noInf >= 0.5 && noInf < 1)
            this.etat = Code_Etat.ORANGE;
        if(noInf >= 1)
            this.etat = Code_Etat.ROUGE;
    }

    public Code_Etat getEtat() {
        return etat;
    }
    
    public void addEvenement(Evenement e){
        this.listeEvenements.add(e);
    }
    
    public void deleteEvenement(Evenement e){
        this.listeEvenements.remove(e);
    }

    public ArrayList<Evenement> getListeEvenements() {
        return listeEvenements;
    }
    
    public boolean verifiePermissionInterieur(){
        this.setEtat();
        Code_Etat c = this.getEtat();
        if(c.equals(Code_Etat.ROUGE) || c.equals(Code_Etat.ORANGE))
            return false;
        return true;
    }
    
    public boolean verifiePermissionExterieur(){
        return true;
    }
    
    public boolean verifieDensiteInterieur(Evenement e){
        Location loc = e.getLocation();
        if(this.verifiePermissionInterieur()){
            if(loc.verifieConformiteInterieur() >= 0)
                return true;
        }
        return false;
    }
    
    public boolean verifieDensiteExterieur(Evenement e){
        Location loc = e.getLocation();
        if(this.verifiePermissionExterieur()){
            if(loc.verifieConformiteExterieur() >= 0)
                return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Ville{" + "nom=" + nom + ", noCas=" + noCas + ", noResidents=" + noResidents + ", etat=" + etat + '}';
    }
    
    
}
