package projet;

import java.util.ArrayList;

public class Client extends Utilisateur{
    private ArrayList<Evenement> listeFavoris = new ArrayList<Evenement>();

    public Client() {
    }

    public Client(int ID, String nom, String prenom, String tel, String email, String mot_de_passe) {
        super(ID, nom, prenom, tel, email, mot_de_passe);
    }
    
    public void ajouterEvenementAuxFavoris(Evenement evenement){
        listeFavoris.add(evenement);
    }
    
    public void supprimerEvenementDeFavoris(Evenement evenement){
        listeFavoris.remove(evenement);
    }

    public ArrayList<Evenement> getListeFavoris() {
        return listeFavoris;
    }

    public String acheterBilletExterieur(Evenement evenement){
        int nr_tot = evenement.getLocation().getNb_total_places();
        int nr_ext = evenement.getLocation().getNb_places_exterieur();
        if(nr_ext >= 1){
            evenement.getLocation().setNb_total_places(nr_tot--);
            evenement.getLocation().setNb_places_exterieur(nr_ext--);
            return evenement.getLienVersBillet();
        }
        return "Aucun place disponible a l'exterieur";
    }
    
    public String acheterBilletInterieur(Evenement evenement){
        int nr_tot = evenement.getLocation().getNb_total_places();
        int nr_int = evenement.getLocation().getNb_places_interieur();
        if(nr_int >= 1){
            evenement.getLocation().setNb_total_places(nr_tot--);
            evenement.getLocation().setNb_places_exterieur(nr_int--);
            return evenement.getLienVersBillet();
        }
        return "Aucun place disponible a l'interieur";
    }
}
